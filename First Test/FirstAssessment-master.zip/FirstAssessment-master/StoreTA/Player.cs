﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreTA
{
    public class Player
    {
        public static int playerMoney = 60;
        public static int pocketSpace = 4;
        public static int currentItems = 0;
        public static int taxTicket = 1;

    }

}
