The simulator is played as so:

The computer first asks for your name, so beware that you don't accidently call yourself a drink!

The computer then proceeds to mention what the store has in stock(Outfits, Merch, GConsoles),
in which you must type out what you want to view.

After choosing one of the three bundles, the computer will ask what items you want to buy out 
of the bundle.

You can buy as much as you want, but keep close eye of your money count and pocket space.

You can exit by typing 'exit' (there is this bug that only lets you leave AFTER choosing a bundle).

Also take a gander at 'StoreInfo' if you want.